package com.cureme.service.main;

import java.util.Date;

public class DiagnognosticsFeedBack {

	private String feedbackId;
	private String diagnosticsUserName;
	private String patientUserName;
	private String feedback;
	private String feedbackDate;
	public String getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(String feedbackId) {
		this.feedbackId = feedbackId;
	}
	public String getDiagnosticsUserName() {
		return diagnosticsUserName;
	}
	public void setDiagnosticsUserName(String diagnosticsUserName) {
		this.diagnosticsUserName = diagnosticsUserName;
	}
	public String getPatientUserName() {
		return patientUserName;
	}
	public void setPatientUserName(String patientUserName) {
		this.patientUserName = patientUserName;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public String getFeedbackDate() {
		return feedbackDate;
	}
	public void setFeedbackDate(String feedbackDate) {
		this.feedbackDate = feedbackDate;
	}
	
	
}
