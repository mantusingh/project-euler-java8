package com.cureme.service.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DiagnosticAppointmentService {

	@RequestMapping(value="/bookDiagnosticAppointment", method = RequestMethod.POST)
    public void process(@RequestBody String string) throws Exception {
		System.out.println(string);
	List<String> appointmentFieldList=Arrays.asList(string.split("&"));
	Map<String,String> appointmentFieldMap=new HashMap<>();
	for (String string2 : appointmentFieldList) {
		String[] array=string2.split("=");
		String at_0=array[0];
		String at_1=array[1];
		appointmentFieldMap.put(at_0, at_1);
	}
	String appointmentDate=null;
	String appointmentTime=null;
	String memberFirstName=null;
	if(appointmentFieldMap.get("appointmentDate")!=null&& !appointmentFieldMap.get("appointmentDate").isEmpty()){
	appointmentDate=appointmentFieldMap.get("appointmentDate");
	}
	if(appointmentFieldMap.get("appointmentTime")!=null&& !appointmentFieldMap.get("appointmentTime").isEmpty()){
	appointmentTime=appointmentFieldMap.get("appointmentTime");
	}
	if(appointmentFieldMap.get("memberFirstName")!=null&& !appointmentFieldMap.get("memberFirstName").isEmpty()){
	memberFirstName=appointmentFieldMap.get("memberFirstName");
	}
	SimpleDateFormat simpleDateFormnat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.ENGLISH);
	//java.sql.Date date=new java.sql.Date(Long.parseLong(appointmentDate));
	java.sql.Date date=new java.sql.Date(simpleDateFormnat.parse(appointmentDate).getTime());
	Connection conn=DatabaseConnection.getConnection();
    String selectQuery="insert into patientappointmentdiagnostics (APPOINTMENTID,DIAGNOSTICSUSERNAME,PATIENTUSERNAME,APPOINTMENTREQUESTDATETIME,APPOINTMENTDATETIME,RFQID,TESTSORREMARKS,CLOSED) values(?,?,?,?,?,?,?,?)";
   
    System.out.println(selectQuery);
    PreparedStatement ps = conn.prepareStatement(selectQuery);
    ps.setString(1, "2");
    ps.setString(2, "accumeddiagnostics");
    ps.setString(3, memberFirstName);
    ps.setDate(4, (java.sql.Date) date);
    ps.setDate(5, new java.sql.Date(new Date().getTime()));
    ps.setString(6, null);
    ps.setString(7, null);
    ps.setString(8, "N");
    ps.execute();
    System.out.println("Done");
    }
}
