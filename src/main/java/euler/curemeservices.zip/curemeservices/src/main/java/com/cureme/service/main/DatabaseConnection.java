package com.cureme.service.main;

import java.io.File;
import java.io.FileInputStream;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;



@Component
public class DatabaseConnection {

	@Value("${project.database.username}")
	private static String userName;
	
	@Value("${project.database.password}")
	private static String password;
	
	@Value("${project.database.servername}")
	private static String serverName;


	public static Connection con;

	public static Connection getConnection() throws Exception
	{
		
		//final String user=properties.getProperty("project.database.username");
		//final String pass=properties.getProperty("project.database.password");
			
		String url="jdbc:oracle:thin:@"+"localhost"+":1521:orcl";
		 
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection(url, "cureme", "cureme");
			return con;
		}
		catch(Exception e)
		{
			throw e;
		}
	}

}