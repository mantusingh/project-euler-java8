package com.cureme.service.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FeedBackService {
  
  @RequestMapping(value = "/getFeedBack/{id}", method = RequestMethod.GET,headers="Accept=application/json")
  public List<DoctorFeedback> getFeedBack(@PathVariable String id){
    List<DoctorFeedback> feedBackList=new ArrayList<>();
    try{
   /* Class.forName("com.mysql.jdbc.Driver");
    Connection conn = null;
    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cureme","root", "");*/
    Connection conn=DatabaseConnection.getConnection();
    String selectQuery="Select patientusername,feedback,feedbackdate from patientfeedbacktodoctor where doctorusername='"+id+"'";
    //String selectQuery="Select * from patientfeedbacktodoctor";
    PreparedStatement ps = conn.prepareStatement(selectQuery);
    ResultSet rs=ps.executeQuery();
    while(rs.next()){
      //System.out.println(rs.getString("doctorusername"));
      DoctorFeedback doctorFeedback=new DoctorFeedback();
      String feedBack=rs.getString("feedback");
      doctorFeedback.setFeedback(feedBack);
      String patientusername=rs.getString("patientusername");
      doctorFeedback.setPatientusername(patientusername);
      String feedbackdate=rs.getString("feedbackdate");
      doctorFeedback.setFeedbackdate(feedbackdate);
      feedBackList.add(doctorFeedback);
    }
    conn.close();
    }catch(Exception exception){
      exception.printStackTrace();
    }
    return feedBackList;
    
  }

}
