package com.cureme.service.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DiagnognosticsFeedBackService {
	@RequestMapping(value = "/getDiagnognosticsFeedBack/{id}", method = RequestMethod.GET,headers="Accept=application/json")
	  public List<DiagnognosticsFeedBack> getFeedBack(@PathVariable String id){
	    List<DiagnognosticsFeedBack> feedBackList=new ArrayList<>();
	    try{
	    Connection conn=DatabaseConnection.getConnection();
	    String selectQuery="Select * from patientfeedbacktodiagnostics where diagnosticsusername='"+id+"'";
	    PreparedStatement ps = conn.prepareStatement(selectQuery);
	    ResultSet rs=ps.executeQuery();
	    while(rs.next()){
	    	DiagnognosticsFeedBack diagnognosticsFeedBack=new DiagnognosticsFeedBack();
	    	String FEEDBACKID=rs.getString("FEEDBACKID");
		      diagnognosticsFeedBack.setFeedbackId(FEEDBACKID);
	      String FEEDBACK=rs.getString("FEEDBACK");
	      diagnognosticsFeedBack.setFeedback(FEEDBACK);
	      String DIAGNOSTICSUSERNAME=rs.getString("DIAGNOSTICSUSERNAME");
	      diagnognosticsFeedBack.setDiagnosticsUserName(DIAGNOSTICSUSERNAME);
	      String PATIENTUSERNAME=rs.getString("PATIENTUSERNAME");
	      diagnognosticsFeedBack.setPatientUserName(PATIENTUSERNAME);
	      String FEEDBACKDATE=rs.getString("FEEDBACKDATE");
	      diagnognosticsFeedBack.setFeedbackDate(FEEDBACKDATE);
	      feedBackList.add(diagnognosticsFeedBack);
	    }
	    conn.close();
	    }catch(Exception exception){
	      exception.printStackTrace();
	    }
	    return feedBackList;
	}
}
