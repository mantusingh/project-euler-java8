package com.cureme.service.main;

public class DoctorFeedback {

  private String patientusername;
  private String feedback;
  private String feedbackdate;
  
  public String getPatientusername() {
    return patientusername;
  }
  public void setPatientusername(String patientusername) {
    this.patientusername = patientusername;
  }
  public String getFeedback() {
    return feedback;
  }
  public void setFeedback(String feedback) {
    this.feedback = feedback;
  }
  public String getFeedbackdate() {
    return feedbackdate;
  }
  public void setFeedbackdate(String feedbackdate) {
    this.feedbackdate = feedbackdate;
  }
  
}
